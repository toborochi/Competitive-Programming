#include <bits/stdc++.h>
#define IOS ios::sync_with_stdio(0);
using namespace std;

int main()
{
    IOS
    ///freopen("out.txt","w",stdout);
    cout<<""<<endl;
}
/// This code is less virgin than me
